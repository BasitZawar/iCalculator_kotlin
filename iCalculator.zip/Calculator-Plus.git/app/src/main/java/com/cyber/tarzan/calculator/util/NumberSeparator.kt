package com.cyber.tarzan.calculator.util

enum class NumberSeparator {
    OFF,
    INTERNATIONAL,
    INDIAN
}
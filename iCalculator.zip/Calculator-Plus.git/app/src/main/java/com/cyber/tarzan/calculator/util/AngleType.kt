package com.cyber.tarzan.calculator.util

enum class AngleType {
    DEG,
    RAD
}
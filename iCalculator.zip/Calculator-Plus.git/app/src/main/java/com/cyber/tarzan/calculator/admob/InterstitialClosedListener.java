package com.cyber.tarzan.calculator.admob;

public interface InterstitialClosedListener {
    void onInterstitialClosed();
    void onInterstitialFailedToShow();
}

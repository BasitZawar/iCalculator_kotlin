package niam.photo.motion.ads

import com.cyber.tarzan.calculator.BuildConfig


object AdIds {

    private const val admobBannerId = "ca-app-pub-7135106726582637/9114434150"
    private const val admobInterstitialIdHome = "ca-app-pub-7135106726582637/2549025805"
    private const val admobInterstitialIdSplash = ""
    private const val admobNativeId = ""

    private const val admobBannerIdTest = "ca-app-pub-3940256099942544/6300978111"
    private const val admobInterstitialIdTest = "ca-app-pub-3940256099942544/1033173712"
    private const val admobNativeIdTest = "/6499/example/native"

    private const val fbBannerId = ""
    private const val fbInterstitialId = ""
    private const val fbNativeId = ""

    private const val fbBannerIdTest = "IMG_16_9_APP_INSTALL#359277049370456_359278532703641"
    private const val fbInterstitialIdTest = "IMG_16_9_APP_INSTALL#359277049370456_359278672703627"
    private const val fbNativeIdTest = ""


    fun getAdmobBannerId(): String? {
        return if (BuildConfig.DEBUG) {
            admobBannerIdTest
        } else {
            admobBannerId
        }
    }

    fun admobInterstitialIdHome(): String? {
        return if (BuildConfig.DEBUG) {
            admobInterstitialIdTest
        } else {
            admobInterstitialIdHome
        }
    }

    fun admobInterstitialIdSplash(): String? {
        return if (BuildConfig.DEBUG) {
            admobInterstitialIdTest
        } else {
            admobInterstitialIdSplash
        }
    }


    fun getAdmobNativeId(): String? {
        return if (BuildConfig.DEBUG) {
            admobNativeIdTest
        } else {
            admobNativeId
        }
    }


    fun getFbBannerId(): String? {
        return if (BuildConfig.DEBUG) {
            fbBannerIdTest
        } else {
            fbBannerId
        }
    }

    fun getFbInterstitialId(): String? {
        return if (BuildConfig.DEBUG) {
            fbInterstitialIdTest
        } else {
            fbInterstitialId
        }
    }


    fun getFbNativeId(): String? {
        return if (BuildConfig.DEBUG) {
            fbNativeIdTest
        } else {
            fbNativeId
        }
    }


}